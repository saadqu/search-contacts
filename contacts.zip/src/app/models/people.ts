export class People {
  name: string;
  rating: number;
  img: string;
  Description: string;
  Likes: string[];
  Dislikes: string[];
}
